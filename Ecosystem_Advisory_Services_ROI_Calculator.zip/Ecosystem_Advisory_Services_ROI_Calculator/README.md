# OpenText Ecosystem Adivisory Services ROI Calculator

Converting a ROI calculator build in Excel into a HTML and JS app using the corprote website framework.

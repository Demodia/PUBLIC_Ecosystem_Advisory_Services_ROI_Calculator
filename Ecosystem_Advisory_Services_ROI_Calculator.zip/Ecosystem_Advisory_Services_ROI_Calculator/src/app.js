import { getCalculatorElements, setInitialElementAttributes } from "./js/helpers.js";
import { setupDelayedJavascriptArray, setupFormValidation, resetCorporateAjaxSubmit, setupSpeakToExpertBlock } from "./js/corporateFormFunctions.js";
import CalculatorState from "./js/CalculatorState.js";
import Callbacks from "./js/Callbacks.js";
import EventHandlers from "./js/EventHandlers.js";
import RangeSliderManager from "./js/RangeSliderManager.js";
import "./css/custom.css";

const initCalculator = async () => {
  const calculatorElement = document.getElementById("customCalculator");
  const { buttonElements, inputElements, outputElements, resultElements, requiredFieldIDs } = getCalculatorElements(calculatorElement);

  const rangeSliderManager = new RangeSliderManager(inputElements);
  await rangeSliderManager.initRangeSliders();
  const rangeSliders = rangeSliderManager.getRangeSliders();

  const calculatorState = new CalculatorState(requiredFieldIDs, inputElements, outputElements, rangeSliders);
  rangeSliders.forEach((slider) => slider.setState(calculatorState));

  const callbacks = new Callbacks();
  const eventHandlers = new EventHandlers(calculatorElement, buttonElements, inputElements, outputElements, resultElements, calculatorState, rangeSliders, callbacks, requiredFieldIDs);
  eventHandlers.setupEventHandlers();
  eventHandlers.setupEventActions();

  setInitialElementAttributes(resultElements, buttonElements);
};

const initCorporatePatterns = async () => {
  setupDelayedJavascriptArray();
  setupFormValidation();
  resetCorporateAjaxSubmit();
  setupSpeakToExpertBlock();
};

document.addEventListener("DOMContentLoaded", async () => {
  await initCalculator();
  await initCorporatePatterns();
});

/**
 * Returns an object containing all calculator elements.
 * @param {HTMLElement} parent - The parent element containing the calculator elements.
 * @returns {Object} - An object containing all calculator elements.
 */
export const getCalculatorElements = (parent) => {
  const elements = {
    buttonElements: {
      goToCalculator: parent.querySelector("#goToCalculatorButton"),
      resetProgress: parent.querySelector("#resetProgressButton"),
      getResults: parent.querySelector("#getResultsButton"),
      speakToExpert: parent.querySelector("#speakToExpertButton"),
      submit: parent.querySelector("#submitCalculatorButton"),
    },
    inputElements: {
      range: [...parent.querySelectorAll(".calc-field.form-control-range")],
      select: [...parent.querySelectorAll("select.calc-field.form-control")],
    },
    outputElements: {
      savingPotential: parent.querySelector("#savingPotential"),
      effortReduction: parent.querySelector("#effortReduction"),
      returnOnInvestment: parent.querySelector("#returnOnInvestment"),
    },
    resultElements: {
      results: parent.querySelector("#resultsBlocks"),
      preResults: parent.querySelector("#preResults"),
      calculatorOutputs: parent.querySelector("#calculatorOutputs"),
      requestConsultation: parent.querySelector("#requestConsultation"),
    },
  };

  // Check if all elements were found
  for (const [groupKey, group] of Object.entries(elements)) {
    for (const [key, element] of Object.entries(group)) {
      if (!element) {
        console.warn(`Element ${groupKey}.${key} not found`);
      }
    }
  }

  elements.requiredFieldIDs = [...elements.inputElements.range, ...elements.inputElements.select].filter((el) => el && el.required).map((el) => el.id);

  return elements;
};

/**
 * Sets initial attributes for result and button elements.
 * @param {Object} resultElements - An object containing all result elements.
 * @param {Object} buttonElements - An object containing all button elements.
 */
export const setInitialElementAttributes = (resultElements, buttonElements) => {
  resultElements.calculatorOutputs.hidden = true;
  resultElements.requestConsultation.hidden = true;
  buttonElements.resetProgress.disabled = true;
  buttonElements.getResults.disabled = true;
};

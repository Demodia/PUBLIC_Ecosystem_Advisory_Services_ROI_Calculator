import { observable, action, makeObservable, autorun, runInAction } from "mobx";

import Renderer from "./Renderer.js";
import UIResetter from "./UIResetter.js";

const fieldMapping = {
  rangeRevenue: "Q1-CompanyRevenue",
  selectGeography: "Q2-Geography",
  selectERPLandscape: "Q3-ERPLandscape",
  rangeNumberTradingPartners: "Q4-TradingPartners",
  rangeNumberMaps: "Q5-MapsNumber",
  rangeNumberDocTypes: "Q6-DocumentTypes",
  selectMapReduction: "Q7-MapsReduction",
  selectERPFutureState: "Q8-ERPFutureState",
  selectEDIMaturity: "Q9-EDIMaturity",
  selectInternalVsExternalResources: "Q10-Resources",
  outputSavingPotential: "R1-Savings",
  outputEffortReduction: "R2-EffortReduction",
  outputReturnOnInvestment: "R3-ROI",
};

const initializeState = (requiredFieldIDs) => requiredFieldIDs.reduce((acc, id) => ({ ...acc, [id]: null }), { outputSavingPotential: null, outputEffortReduction: null, outputReturnOnInvestment: null });

class CalculatorState {
  @observable state = {};
  @observable isReset = false;

  constructor(requiredFieldIDs, inputElements, outputElements, rangeSliders) {
    makeObservable(this);
    this.state = initializeState(requiredFieldIDs);
    this.renderer = new Renderer(inputElements, outputElements, rangeSliders);
    this.uiResetter = new UIResetter(inputElements, outputElements, this);

    autorun(() => (this.isReset ? this.uiResetter.reset() : this.renderer.render(this.state)));
    autorun(() => this.validateFields() && this.updateHiddenFields());
  }

  validateFields = () => Object.values(this.state).every((val) => val !== null && (typeof val === "string" || val.value !== undefined));

  @action.bound
  updateHiddenFields() {
    Object.keys(this.state).forEach((key) => {
      const hiddenFieldName = fieldMapping[key];
      const hiddenField = document.querySelector(`input[name="${hiddenFieldName}"][type="hidden"]`);
      if (hiddenField) {
        hiddenField.value = typeof this.state[key] === "string" ? this.state[key] : this.state[key].value;
      }
    });
  }

  @action.bound
  set(id, value) {
    this.state[id] = value;
  }

  @action.bound
  reset() {
    this.state = initializeState(Object.keys(this.state));
    this.isReset = true;
    setTimeout(() => this.isReset = false, 0);
  }
}

export default CalculatorState;

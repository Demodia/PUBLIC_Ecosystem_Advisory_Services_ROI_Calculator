/**
 * The Renderer class is responsible for rendering the input and output elements of the application.
 */
class Renderer {
  /**
   * Creates a new instance of the Renderer class.
   * @param {Object} inputElements - The input elements of the application.
   * @param {Object} outputElements - The output elements of the application.
   * @param {Object} rangeSliders - The range sliders of the application.
   */
  constructor(inputElements, outputElements, rangeSliders) {
    this.inputElements = inputElements;
    this.outputElements = outputElements;
    this.rangeSliders = rangeSliders;
  }

  /**
   * Renders a single element based on its state.
   * @param {Object} element - The element to render.
   * @param {Object} state - The state of the element.
   * @param {Function} renderFn - The function to use to render the element.
   */
  renderElement(element, state, renderFn) {
    const elementState = state[element.id];
    if (elementState) {
      renderFn(element, elementState);
    }
  }

  /**
   * Renders the input elements of the application.
   * @param {Object} state - The state of the application.
   */
  renderInputs(state) {
    this.inputElements.range.forEach((input) => this.renderElement(input, state, this.renderRangeInput.bind(this)));
    this.inputElements.select.forEach((select) => this.renderElement(select, state, this.renderSelectInput.bind(this)));
  }

  /**
   * Renders a range input element.
   * @param {Object} input - The range input element to render.
   * @param {Object} inputState - The state of the range input element.
   */
  renderRangeInput(input, inputState) {
    this.rangeSliders.get(input.id).updateRangeInputElementValue();
  }

  /**
   * Renders a select input element.
   * @param {Object} select - The select input element to render.
   * @param {Object} selectState - The state of the select input element.
   */
  renderSelectInput(select, selectState) {
    select.value = selectState.value;
  }

  /**
   * Renders the output elements of the application.
   * @param {Object} state - The state of the application.
   */
  renderResults(state) {
    const { outputSavingPotential, outputEffortReduction, outputReturnOnInvestment } = state;
    if (outputSavingPotential !== null) {
      this.outputElements.savingPotential.textContent = outputSavingPotential;
      this.outputElements.effortReduction.textContent = outputEffortReduction;
      this.outputElements.returnOnInvestment.textContent = outputReturnOnInvestment;
    }
  }

  /**
   * Renders the input and output elements of the application.
   * @param {Object} state - The state of the application.
   */
  render(state) {
    this.renderInputs(state);
    this.renderResults(state);
  }
}

export default Renderer;

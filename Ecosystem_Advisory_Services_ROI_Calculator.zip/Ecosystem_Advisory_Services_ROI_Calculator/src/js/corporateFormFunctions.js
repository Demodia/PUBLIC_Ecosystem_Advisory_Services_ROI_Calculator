// HELPER FUNCTIONS FROM CORPORATE PATTERNS

// Delayed Javascript Array Setup
export const setupDelayedJavascriptArray = () => {
  window.delayedJavascriptArray = window.delayedJavascriptArray || [];
  // Campaign
  var DefaultCampaignId = "50609";
  window.delayedJavascriptArray.push(function () {
    otApi.addJSFiles(["https://img.en25.com/Web/OpenTextGlobal/{ce4e954c-b777-46b1-8f16-e172ddcfd222}_OT-ELQ10-WEM-Form_Dynamic.js"]);
  });
};

// Form Validation
export const setupFormValidation = () => {
  window.delayedJavascriptArray.push(function () {
    otApi.addJSFiles(["https://img.en25.com/i/livevalidation_standalone.compressed.js"], function () {
      // Email address
      var elqEmail = new LiveValidation(document.querySelector("#elq-email"), { validMessage: "", onlyOnBlur: false, wait: 300 });
      elqEmail.add(Validate.Presence, { failureMessage: "This field is required" });
      elqEmail.add(Validate.Format, { pattern: /^([^@\s]+)@((?:[-a-z0-9]+\.)+[a-z]{2,})$/i, failureMessage: "A valid email address is required" });
      elqEmail.add(Validate.Custom, {
        against: function (value) {
          return !value.match(/(<([^>]+)>)/gi);
        },
        failureMessage: "Value must not contain any HTML",
      });

      // First name
      var elqFirstname = new LiveValidation(document.querySelector("#elq-firstname"), { validMessage: "", onlyOnBlur: false, wait: 300 });
      elqFirstname.add(Validate.Custom, {
        against: function (value) {
          return !value.match(/(telnet|ftp|https?):\/\/(?:[a-z0-9][a-z0-9-]{0,61}[a-z0-9]\.|[a-z0-9]\.)+[a-z]{2,63}/i);
        },
        failureMessage: "Value must not contain any URL's",
      });
      elqFirstname.add(Validate.Custom, {
        against: function (value) {
          return !value.match(/(<([^>]+)>)/gi);
        },
        failureMessage: "Value must not contain any HTML",
      });
      elqFirstname.add(Validate.Length, { tooShortMessage: "Invalid length for field value", tooLongMessage: "Invalid length for field value", minimum: 0, maximum: 35 });
      elqFirstname.add(Validate.Presence, { failureMessage: "This field is required" });

      // Last name
      var elqLastname = new LiveValidation(document.querySelector("#elq-lastname"), { validMessage: "", onlyOnBlur: false, wait: 300 });
      elqLastname.add(Validate.Custom, {
        against: function (value) {
          return !value.match(/(telnet|ftp|https?):\/\/(?:[a-z0-9][a-z0-9-]{0,61}[a-z0-9]\.|[a-z0-9]\.)+[a-z]{2,63}/i);
        },
        failureMessage: "Value must not contain any URL's",
      });
      elqLastname.add(Validate.Custom, {
        against: function (value) {
          return !value.match(/(<([^>]+)>)/gi);
        },
        failureMessage: "Value must not contain any HTML",
      });
      elqLastname.add(Validate.Length, { tooShortMessage: "Invalid length for field value", tooLongMessage: "Invalid length for field value", minimum: 0, maximum: 35 });
      elqLastname.add(Validate.Presence, { failureMessage: "This field is required" });

      // Country
      var elqCountry = new LiveValidation(document.querySelector("#elq-country"), { validMessage: "", onlyOnBlur: false, wait: 300 });
      elqCountry.add(Validate.Presence, { failureMessage: "This field is required" });

      // State or province
      var elqState = new LiveValidation(document.querySelector("#elq-state"), { validMessage: "", onlyOnBlur: false, wait: 300 });

      // Company
      var elqCompany = new LiveValidation(document.querySelector("#elq-company"), { validMessage: "", onlyOnBlur: false, wait: 300 });
      elqCompany.add(Validate.Custom, {
        against: function (value) {
          return !value.match(/(<([^>]+)>)/gi);
        },
        failureMessage: "Value must not contain any HTML",
      });
      elqCompany.add(Validate.Length, { tooShortMessage: "Invalid length for field value", tooLongMessage: "Invalid length for field value", minimum: 0, maximum: 35 });
      elqCompany.add(Validate.Presence, { failureMessage: "This field is required" });

      // Industry
      var elqIndustry = new LiveValidation(document.querySelector("#elq-industry"), { validMessage: "", onlyOnBlur: false, wait: 300 });
      elqIndustry.add(Validate.Presence, { failureMessage: "This field is required" });

      // Title
      var elqTitle = new LiveValidation(document.querySelector("#elq-title"), { validMessage: "", onlyOnBlur: false, wait: 300 });
      elqTitle.add(Validate.Custom, {
        against: function (value) {
          return !value.match(/(telnet|ftp|https?):\/\/(?:[a-z0-9][a-z0-9-]{0,61}[a-z0-9]\.|[a-z0-9]\.)+[a-z]{2,63}/i);
        },
        failureMessage: "Value must not contain any URL's",
      });
      elqTitle.add(Validate.Custom, {
        against: function (value) {
          return !value.match(/(<([^>]+)>)/gi);
        },
        failureMessage: "Value must not contain any HTML",
      });
      elqTitle.add(Validate.Presence, { failureMessage: "This field is required" });
      elqTitle.add(Validate.Length, { tooShortMessage: "Invalid length for field value", tooLongMessage: "Invalid length for field value", minimum: 0, maximum: 35 });

      // Business phone
      var elqBusphone = new LiveValidation(document.querySelector("#elq-busphone"), { validMessage: "", onlyOnBlur: false, wait: 300 });
      elqBusphone.add(Validate.Custom, {
        against: function (value) {
          return !value.match(/(telnet|ftp|https?):\/\/(?:[a-z0-9][a-z0-9-]{0,61}[a-z0-9]\.|[a-z0-9]\.)+[a-z]{2,63}/i);
        },
        failureMessage: "Value must not contain any URL's",
      });
      elqBusphone.add(Validate.Custom, {
        against: function (value) {
          return !value.match(/(<([^>]+)>)/gi);
        },
        failureMessage: "Value must not contain any HTML",
      });
      elqBusphone.add(Validate.Length, { tooShortMessage: "Invalid length for field value", tooLongMessage: "Invalid length for field value", minimum: 0, maximum: 35 });
      elqBusphone.add(Validate.Presence, { failureMessage: "This field is required" });
    });
  });
};

// Reset Corporate Ajax Submit
export const resetCorporateAjaxSubmit = () => {
  const submitAnotherRequestBtn = document.getElementById("submitAnotherRequest");
  const ajaxSubmitForm = document.querySelector(".js-ajax-submit-form");
  const ajaxSubmitThankYou = document.querySelector(".js-ajax-submit-thankyou");
  const submitCalculatorButton = document.getElementById("submitCalculatorButton");

  submitAnotherRequestBtn.addEventListener("click", function () {
    // Remove the 'active' class from 'ajax-submit-thankyou'
    ajaxSubmitThankYou.classList.remove("active");

    // Add the 'active' class back to 'ajax-submit-form'
    ajaxSubmitForm.classList.add("active");

    // Enable the submit button if it was disabled
    submitCalculatorButton.removeAttribute("disabled");

    // Reverse other changes made by the corporate JS here...
    // Form feedback??
  });
};

// Speak to Expert Block Collapse Shown
export const setupSpeakToExpertBlock = () => {
  const speakToAnExpertBlock = document.getElementById("speakToAnExpertBlock");

  $(speakToAnExpertBlock).on("shown.bs.collapse", function () {
    // Scroll into view
    speakToAnExpertBlock.scrollIntoView({
      behavior: "smooth",
      block: "start",
    });

    // Focus on the first visible input field
    const firstVisibleInput = speakToAnExpertBlock.querySelector('input:not([type="hidden"]):not([disabled]), select:not([disabled]), textarea:not([disabled])');
    if (firstVisibleInput) {
      firstVisibleInput.focus();
    }
  });
};

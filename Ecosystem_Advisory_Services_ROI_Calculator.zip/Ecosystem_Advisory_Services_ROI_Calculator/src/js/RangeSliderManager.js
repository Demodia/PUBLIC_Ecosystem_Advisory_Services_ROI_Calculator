import RangeSlider from './RangeSlider.js';

class RangeSliderManager {
  constructor(inputElements) {
    this.rangeSliders = new Map();
    this.inputElements = inputElements;
  }

  initRangeSliders() {
    this.inputElements.range.forEach(input => this.rangeSliders.set(input.id, new RangeSlider(input, this)));
  }

  getRangeSliders() {
    return this.rangeSliders;
  }
}

export default RangeSliderManager;

import RangeSlider from './RangeSlider.js';

class RangeSliderManager {
  constructor(inputElements) {
    this.rangeSliders = new Map();
    this.inputElements = inputElements;
  }

  initRangeSliders() {
    this.inputElements.range.forEach(input => {
      const slider = new RangeSlider(input, this);
      slider.configureNumberInput();
      this.rangeSliders.set(input.id, slider);
    });
  }
  

  getRangeSliders() {
    return this.rangeSliders;
  }
}

export default RangeSliderManager;

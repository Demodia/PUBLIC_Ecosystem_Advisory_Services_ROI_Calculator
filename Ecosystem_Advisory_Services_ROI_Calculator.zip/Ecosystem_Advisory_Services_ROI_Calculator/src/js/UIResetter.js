/**
 * A class for resetting UI elements to their default state.
 */
class UIResetter {
  /**
   * Creates a new UIResetter instance.
   * @param {Object} inputElements - An object containing input elements to reset.
   * @param {Object} outputElements - An object containing output elements to reset.
   */
  constructor(inputElements, outputElements) {
    this.inputElements = inputElements;
    this.outputElements = outputElements;
  }

  /**
   * Resets all input and output elements.
   */
  reset() {
    this.resetInputs();
    this.resetOutputs();
  }

  /**
   * Resets an array of elements using a reset function.
   * @param {Array} elements - An array of elements to reset.
   * @param {Function} resetFn - A function to use for resetting each element.
   */
  resetElement(elements, resetFn) {
    elements.forEach(resetFn);
  }

  /**
   * Resets all range input elements.
   */
  resetInputs() {
    this.resetElement(this.inputElements.range, this.resetRangeInput.bind(this));
    this.resetElement(this.inputElements.range, this.resetNumberInput.bind(this));
    this.resetElement(this.inputElements.select, this.resetSelectInput.bind(this));
  }

  /**
   * Resets all output elements.
   */
  resetOutputs() {
    ["savingPotential", "effortReduction"].forEach((key) => {
      this.outputElements[key].textContent = "0";
    });
  }

  /**
   * Resets a range input element to its default state.
   * @param {HTMLElement} input - The range input element to reset.
   */
  resetRangeInput(input) {
    input.value = input.min;
    input.style.removeProperty("--value");
    input.classList.remove("has-value");
  }

  resetNumberInput(input) {
    const parentDiv = input.closest(".row");
    if (parentDiv) {
      const outputElement = parentDiv.querySelector(".range-value");
      if (outputElement) {
        outputElement.value = "";  // Resetting to empty string
      }
    }
  }

  /**
   * Resets a select input element to its default state.
   * @param {HTMLElement} select - The select input element to reset.
   */
  resetSelectInput(select) {
    select.selectedIndex = 0;
  }
}

export default UIResetter;

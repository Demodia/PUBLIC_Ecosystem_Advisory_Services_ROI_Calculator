const excelMROUND = (numToRound, numToRoundTo) => {
  numToRoundTo = 1 / numToRoundTo;
  return Math.round(numToRound * numToRoundTo) / numToRoundTo;
};

class SpreadsheetFormulas {
  constructor(state) {
    this.state = state;
  }

  // Method to log out an object containing each getter with it's calculated value
  logGetterValues() {
    const getterValues = {};
    for (const prop of Object.getOwnPropertyNames(this.constructor.prototype)) {
      const descriptor = Object.getOwnPropertyDescriptor(this.constructor.prototype, prop);
      if (descriptor.get) {
        getterValues[prop] = this[prop];
      }
    }
  }

  // Getters are references to cells in the spreadsheet, the name of the getter is cell
  // Getters return JavaScript "translations" of cell formulas
  // Each Getter has the original formula in a comment
  // Getters f6 to f15 use live values from the calculator state
  // The last 3 Getters c22, c23 and c26 are the results
  get aq13() {
    // 3000
    return 3000;
  }
  get aq14() {
    // =(81.5*1.3)*8
    return 81.5 * 1.3 * 8;
  }
  get aq15() {
    // =AQ13/AQ14
    return this.aq13 / this.aq14;
  }
  get aq16() {
    // =((AQ13*0.7+AQ14*0.3)/AQ14)
    return (this.aq13 * 0.7 + this.aq14 * 0.3) / this.aq14;
  }
  get aq17() {
    // =((AQ13*0.3+AQ14*0.7)/AQ14)
    return (this.aq13 * 0.3 + this.aq14 * 0.7) / this.aq14;
  }
  get aq18() {
    // =AQ14/AQ14
    return this.aq14 / this.aq14;
  }

  get f6() {
    // =_xlfn.XLOOKUP(C6,Table1[Select from List],Table1[0],0,)
    return Number(this.state.rangeRevenue.data);
  }
  get f7() {
    // =_xlfn.XLOOKUP(C7,Table2[Select from List],Table2[Weight],0,)
    return Number(this.state.selectGeography.data);
  }
  get f8() {
    // =_xlfn.XLOOKUP(C8,Table3[Select from List],Table3[Weight],0,)
    return Number(this.state.selectERPLandscape.data);
  }
  get f9() {
    // =_xlfn.XLOOKUP(C9,Table7[Select from List],Table7[Weight],0,)
    return Number(this.state.rangeNumberTradingPartners.data);
  }
  get f10() {
    // =_xlfn.XLOOKUP(C10,Table8[Select from List],Table8[Weight],0,)
    return Number(this.state.rangeNumberMaps.data);
  }
  get f11() {
    // =_xlfn.XLOOKUP(C11,Table9[Select from List],Table9[Weight],0,)
    return Number(this.state.rangeNumberDocTypes.data);
  }
  get f12() {
    // =_xlfn.XLOOKUP(C12,Table4[Select from List],Table4[Weight],0,)
    return Number(this.state.selectMapReduction.data);
  }
  get f13() {
    // =_xlfn.XLOOKUP(C13,Table10[Select from List],Table10[Weight],0,)
    return Number(this.state.selectERPFutureState.data);
  }
  get f14() {
    // =_xlfn.XLOOKUP(C14,Table5[Select from List],Table5[Weight],0,)
    return Number(this.state.selectEDIMaturity.data);
  }
  get f15() {
    // =_xlfn.XLOOKUP(C15,Table6[Select from List],Table6[Weight],0,)
    const getterName = this.state.selectInternalVsExternalResources.data;
    return this[getterName];
  }
  get f19() {
    // =F6*F7*F8*F9*F10*F11*F12*F14*F15
    return this.f6 * this.f7 * this.f8 * this.f9 * this.f10 * this.f11 * this.f12 * this.f14 * this.f15;
  }

  get h5() {
    // 50000
    return 50000;
  }
  get g7() {
    // =_xlfn.XLOOKUP(C7,Table2[Select from List],Table2[PricingWt],0,)
    return 50000;
  }
  get g8() {
    // =_xlfn.XLOOKUP(C8,Table3[Select from List],Table3[PricingWt],0,)
    if (this.f8 == 1) {
      return 50000;
    } else if (this.f8 == 1.2) {
      return 100000;
    } else if (this.f8 == 1.5) {
      return 200000;
    }
  }
  get h8() {
    // =G8
    return this.g8;
  }
  get h7() {
    // =IF(F7=1,F7*G7,IF(F7=1.2,G7+H5,IF(F7=1.3,G7+H5+H5,0)))
    if (this.f7 == 1) {
      return this.f7 * this.g7;
    } else if (this.f7 == 1.2) {
      return this.g7 + this.h5;
    } else if (this.f7 == 1.3) {
      return this.g7 + this.h5 + this.h5;
    }
  }
  get h19() {
    // =SUM(H7:H8)
    return this.h7 + this.h8;
  }

  get j30() {
    // 0.38
    return 0.38;
  }
  get j31() {
    // 0.38
    return 0.38;
  }
  get j32() {
    // 0.38
    return 0.38;
  }
  get j33() {
    // 0.38
    return 0.38;
  }
  get j34() {
    // 0.38
    return 0.38;
  }
  get j37() {
    // =F10
    return this.f10;
  }
  get j38() {
    // =J37*J32
    return this.j37 * this.j32;
  }
  get j39() {
    // 15
    return 15;
  }
  get j40() {
    // 20
    return 20;
  }
  get j41() {
    // 39
    return 39;
  }
  get j42() {
    // =(J40/J39)*J41
    return (this.j40 / this.j39) * this.j41;
  }
  get j44() {
    // 50%
    return 0.5;
  }
  get j45() {
    // 106
    return 106;
  }
  get j46() {
    // =J45/(1-(J44))
    return this.j45 / (1 - this.j44);
  }

  get k45() {
    // 16
    return 16;
  }
  get k46() {
    // =K45/(1-(J44))
    return this.k45 / (1 - this.j44);
  }

  get j47() {
    // =(J46*0.7+K46*0.3)
    return this.j46 * 0.7 + this.k46 * 0.3;
  }
  get j48() {
    // =1220/J41
    return 1220 / this.j41;
  }
  get j49() {
    // =J48/(1-(J44))
    return this.j48 / (1 - this.j44);
  }
  get j50() {
    // =81.5*1.3
    return 81.5 * 1.3;
  }
  get j51() {
    // =J48
    return this.j48;
  }
  get j52() {
    // 16
    return 16;
  }
  get j53() {
    // 80
    return 80;
  }
  get j54() {
    // 33%
    return 0.33;
  }
  get j56() {
    // =($J$37*J32)*J39
    return this.j37 * this.j32 * this.j39;
  }
  get j57() {
    // =($J$37*J32)*J40
    return this.j37 * this.j32 * this.j40;
  }
  get j62() {
    // =($J$37*J32)*J41
    return this.j37 * this.j32 * this.j41;
  }
  get j63() {
    // =($J$37*J32)*J42
    return this.j37 * this.j32 * this.j42;
  }

  get k30() {
    // 0.57
    return 0.57;
  }
  get k31() {
    // 0.57
    return 0.57;
  }
  get k32() {
    // 0.57
    return 0.57;
  }
  get k33() {
    // 0.57
    return 0.57;
  }
  get k34() {
    // 0.57
    return 0.57;
  }
  get k37() {
    // ?? BLANK CELL ??
    return 0;
  }
  get k38() {
    // =J37*K32
    return this.j37 * this.k32;
  }
  get k39() {
    // 6
    return 6;
  }
  get k40() {
    // 15
    return 15;
  }
  get k41() {
    // 28
    return 28;
  }
  get k42() {
    // =(K40/K39)*K41
    return (this.k40 / this.k39) * this.k41;
  }
  get k45() {
    // 16
    return 16;
  }
  get k46() {
    // =K45/(1-(J44))
    return this.k45 / (1 - this.j44);
  }
  get k47() {
    // =(J46*0.3)+(K46*0.7)
    return this.j46 * 0.3 + this.k46 * 0.7;
  }
  get k48() {
    // =735/K41
    return 735 / this.k41;
  }
  get k49() {
    // =K48/(1-(J44))
    return this.k48 / (1 - this.j44);
  }
  get k50() {
    // =J50
    return this.j50;
  }
  get k51() {
    // =K48
    return this.k48;
  }
  get k53() {
    // 40
    return 40;
  }
  get k56() {
    // =($J$37*K32)*K39
    return this.j37 * this.k32 * this.k39;
  }
  get k57() {
    // =($J$37*K32)*K40
    return this.j37 * this.k32 * this.k40;
  }
  get k62() {
    // =($J$37*K32)*K41
    return this.j37 * this.k32 * this.k41;
  }
  get k63() {
    // =($J$37*K32)*K42
    return this.j37 * this.k32 * this.k42;
  }
  get k68() {
    // =F11*J52
    return this.f11 * this.j52;
  }
  get k69() {
    // =IF(F6<1,F11*J53,F11*K53)
    if (this.f6 < 1) {
      return this.f11 * this.j53;
    } else {
      return this.f11 * this.k53;
    }
  }
  get k70() {
    // =IF(F6<=1,F11*J53,F11*K53)
    if (this.f6 <= 1) {
      return this.f11 * this.j53;
    } else {
      return this.f11 * this.k53;
    }
  }
  get k74() {
    // =K37*15
    return this.k37 * 15;
  }
  get k75() {
    // =IF(C9=0, 0,120)
    if (this.c9 === 0) {
      return 0;
    }
    return 120;
  }

  get l30() {
    // 0.4
    return 0.04;
  }
  get l31() {
    // 0.4
    return 0.04;
  }
  get l32() {
    // 0.4
    return 0.04;
  }
  get l33() {
    // 0.4
    return 0.04;
  }
  get l34() {
    // 0.4
    return 0.04;
  }
  get l38() {
    // =J37*L32
    return this.j37 * this.l32;
  }
  get l39() {
    // 18
    return 18;
  }
  get l40() {
    // 30
    return 30;
  }
  get l41() {
    // 63
    return 63;
  }
  get l42() {
    // =(L40/L39)*L41
    return (this.l40 / this.l39) * this.l41;
  }
  get l47() {
    // =J46*1
    return this.j46 * 1;
  }
  get l48() {
    // =2000/L41
    return 2000 / this.l41;
  }
  get l49() {
    // =L48/(1-(J44))
    return this.l48 / (1 - this.j44);
  }
  get l50() {
    // =J50
    return this.j50;
  }
  get l51() {
    // =L48
    return this.l48;
  }
  get l56() {
    // =($J$37*L32)*L39
    return this.j37 * this.l32 * this.l39;
  }
  get l57() {
    // =($J$37*L32)*L40
    return this.j37 * this.l32 * this.l40;
  }
  get l62() {
    // =($J$37*L32)*L41
    return this.j37 * this.l32 * this.l41;
  }
  get l63() {
    // =($J$37*L32)*L42
    return this.j37 * this.l32 * this.l42;
  }

  get m56() {
    // =SUM(J56:L56)
    return this.j56 + this.k56 + this.l56;
  }
  get m57() {
    // =SUM(J57:L57)
    return this.j57 + this.k57 + this.l57;
  }
  get m62() {
    // =SUM(J62:L62)
    return this.j62 + this.k62 + this.l62;
  }
  get m63() {
    // =SUM(J63:L63)
    return this.j63 + this.k63 + this.l63;
  }
  get m68() {
    // =K68
    return this.k68;
  }
  get m69() {
    // =K69
    return this.k69;
  }
  get m74() {
    // =K74
    return this.k74;
  }
  get m75() {
    // =K75
    return this.k75;
  }

  get n56() {
    // =M56/8
    return this.m56 / 8;
  }
  get n57() {
    // =M57/8
    return this.m57 / 8;
  }
  get n62() {
    // =M62/8
    return this.m62 / 8;
  }
  get n63() {
    // =M63/8
    return this.m63 / 8;
  }
  get n68() {
    // =M68/8
    return this.m68 / 8;
  }
  get n69() {
    // =M69/8
    return this.m69 / 8;
  }
  get n74() {
    // =M74/8
    return this.m74 / 8;
  }
  get n75() {
    // =M75/8
    return this.m75 / 8;
  }

  get o56() {
    // =N56*(F6*F7*F8*F12*F13*F14)
    return this.n56 * (this.f6 * this.f7 * this.f8 * this.f12 * this.f13 * this.f14);
  }
  get o57() {
    // =N57*(F6*F7*F8*F13*F14)
    return this.n57 * (this.f6 * this.f7 * this.f8 * this.f13 * this.f14);
  }
  get o58() {
    // =O57-O56
    return this.o57 - this.o56;
  }
  get o62() {
    // =N62*(F6*F7*F8*F12*F13*F14)
    return this.n62 * (this.f6 * this.f7 * this.f8 * this.f12 * this.f13 * this.f14);
  }
  get o63() {
    // =N62*(F6*F7*F8*F12*F13*F14)
    return this.n63 * (this.f6 * this.f7 * this.f8 * this.f13 * this.f14);
  }
  get o64() {
    // =O63-O62
    return this.o63 - this.o62;
  }
  get o68() {
    // =N68*(F6*F7*F8*F13*F14)
    return this.n68 * (this.f6 * this.f7 * this.f8 * this.f13 * this.f14);
  }
  get o69() {
    // =N69*(F6*F7*F8*F13*F14)
    return this.n69 * (this.f6 * this.f7 * this.f8 * this.f13 * this.f14);
  }
  get o70() {
    // =O69-O68
    return this.o69 - this.o68;
  }
  get o75() {
    // =N75-N74
    return this.n75 - this.n74;
  }
  get o82() {
    // =IF(O58+O64+O70+O75>550, 550, O58+O64+O70+O75)
    if (this.o58 + this.o64 + this.o70 + this.o75 > 550) {
      return 550;
    } else {
      return this.o58 + this.o64 + this.o70 + this.o75;
    }
  }
  get o83() {
    // =ROUNDUP(O82*0.7,0)
    return Math.round(this.o82 * 0.7);
  }

  get p56() {
    // =((J56*J47)+(K56*K47)+(L56*L47))*(1+J54)
    return (this.j56 * this.j47 + this.k56 * this.k47 + this.l56 * this.l47) * (1 + this.j54);
  }
  get p57() {
    // =((J57*J50)+(K57*K50)+(L57*L50))*(1+J54)
    return (this.j57 * this.j50 + this.k57 * this.k50 + this.l57 * this.l50) * (1 + this.j54);
  }
  get p62() {
    // =((J62*J49)+(K62*K49)+(L62*L49))*(1+J54)
    return (this.j62 * this.j49 + this.k62 * this.k49 + this.l62 * this.l49) * (1 + this.j54);
  }
  get p63() {
    // =((J63*J51)+(K63*K51)+(L63*L51))*(1+J54)
    return (this.j63 * this.j51 + this.k63 * this.k51 + this.l63 * this.l51) * (1 + this.j54);
  }
  get p68() {
    // =(M68*J46)*(1+J54)
    return this.m68 * this.j46 * (1 + this.j54);
  }
  get p69() {
    // =(M69*J50)*(1+J54)
    return this.m69 * this.j50 * (1 + this.j54);
  }
  get p74() {
    // =L74*100
    return 0;
  }
  get p75() {
    // =M75*J50
    return this.m75 * this.j50;
  }
  get p76() {
    // =P74-P75
    return this.p74 - this.p75;
  }

  get q56() {
    // =P56*(F6*F7*F8*F12*F13*F14)
    return this.p56 * (this.f6 * this.f7 * this.f8 * this.f12 * this.f13 * this.f14);
  }
  get q57() {
    // =P57*(F6*F7*F8*F13*F14*F15)
    return this.p57 * (this.f6 * this.f7 * this.f8 * this.f13 * this.f14 * this.f15);
  }
  get q58() {
    // =Q56-Q57
    return this.q56 - this.q57;
  }
  get q62() {
    // =P62*(F6*F7*F8*F12*F13*F14)
    return this.p62 * (this.f6 * this.f7 * this.f8 * this.f12 * this.f13 * this.f14);
  }
  get q63() {
    // =P63*(F6*F7*F8*F13*F14*F15)
    return this.p63 * (this.f6 * this.f7 * this.f8 * this.f13 * this.f14 * this.f15);
  }
  get q64() {
    // =Q62-Q63
    return this.q62 - this.q63;
  }
  get q68() {
    // =P68*(F6*F7*F8*F13*F14)
    return this.p68 * (this.f6 * this.f7 * this.f8 * this.f13 * this.f14);
  }
  get q69() {
    // =P69*(F6*F7*F8*F13*F14*F15)
    return this.p69 * (this.f6 * this.f7 * this.f8 * this.f13 * this.f14 * this.f15);
  }
  get q70() {
    // =Q68-Q69
    return this.q68 - this.q69;
  }

  get p78() {
    // =-(Q58+Q64+Q70+P76)
    return -(this.q58 + this.q64 + this.q70 + this.p76);
  }
  get p79() {
    // =(MROUND(P78*0.7,250000))
    return excelMROUND(this.p78 * 0.7, 250000);
  }
  get p80() {
    // =(P79-H19)/H19
    return (this.p79 - this.h19) / this.h19;
  }
  get p83() {
    // =ROUNDUP(O82*1.3,0)
    return Math.round(this.o82 * 1.3);
  }

  get q79() {
    // =MROUND(P78*1.2,250000)
    return excelMROUND(this.p78 * 1.2, 250000);
  }
  get q80() {
    // =(Q79-H19)/H19
    return (this.q79 - this.h19) / this.h19;
  }

  get i6() {
    // =$P$56*F6
    return this.p56 * this.f6;
  }
  get i7() {
    // =I6*F7
    return this.i6 * this.f7;
  }
  get i8() {
    // =I7*F8
    return this.i7 * this.f8;
  }
  get i12() {
    // =I8*F12
    return this.i8 * this.f12;
  }
  get i13() {
    // =I12*F13
    return this.i12 * this.f13;
  }
  get i14() {
    // =I13*F14
    return this.i13 * this.f14;
  }
  get i19() {
    // =I14
    return this.i14;
  }

  get j6() {
    // =$P$57*F6
    return this.p57 * this.f6;
  }
  get j7() {
    // =J6*F7
    return this.j6 * this.f7;
  }
  get j8() {
    // =J7*F8
    return this.j7 * this.f8;
  }
  get j13() {
    // = J8*F13
    return this.j8 * this.f13;
  }
  get j14() {
    // = J13*F14
    return this.j13 * this.f14;
  }
  get j15() {
    // = J14*F15
    return this.j14 * this.f15;
  }
  get j19() {
    // =J15
    return this.j15;
  }

  get k6() {
    // =$P$68*F6
    return this.p68 * this.f6;
  }
  get k7() {
    // =K6*F7
    return this.k6 * this.f7;
  }
  get k8() {
    // =K7*F8
    return this.k7 * this.f8;
  }
  get k13() {
    // =K8*F13
    return this.k8 * this.f13;
  }
  get k14() {
    // =K13*F14
    return this.k13 * this.f14;
  }
  get k19() {
    // =K14
    return this.k14;
  }

  get l6() {
    // =$P$69*F6
    return this.p69 * this.f6;
  }
  get l7() {
    // =L6*F7
    return this.l6 * this.f7;
  }
  get l8() {
    // =L7*F8
    return this.l7 * this.f8;
  }
  get l13() {
    // =L8*F13
    return this.l8 * this.f13;
  }
  get l14() {
    // =L13*F14
    return this.l13 * this.f14;
  }
  get l15() {
    // =L14*F15
    return this.l14 * this.f15;
  }
  get l19() {
    // =L15
    return this.l15;
  }

  get n6() {
    // =$N$56*F6
    return this.n56 * this.f6;
  }
  get n7() {
    // =N6*F7
    return this.n6 * this.f7;
  }
  get n8() {
    // =N7*F8
    return this.n7 * this.f8;
  }
  get n12() {
    // =N8*F12
    return this.n8 * this.f12;
  }
  get n13() {
    // =N12*F13
    return this.n12 * this.f13;
  }
  get n14() {
    // =N13*F14
    return this.n13 * this.f14;
  }
  get n19() {
    // =N14
    return this.n14;
  }

  get o6() {
    // =$N$57*F6
    return this.n57 * this.f6;
  }
  get o7() {
    // =O6*F7
    return this.o6 * this.f7;
  }
  get o8() {
    // =O7*F8
    return this.o7 * this.f8;
  }
  get o13() {
    // =O8*F13
    return this.o8 * this.f13;
  }
  get o14() {
    // =O13*F14
    return this.o13 * this.f14;
  }
  get o19() {
    // =O14
    return this.o14;
  }

  get p6() {
    // =$N$68*F6
    return this.n68 * this.f6;
  }
  get p7() {
    // =P6*F7
    return this.p6 * this.f7;
  }
  get p8() {
    // =P7*F8
    return this.p7 * this.f8;
  }
  get p13() {
    // =P8*F13
    return this.p8 * this.f13;
  }
  get p14() {
    // =P13*F14
    return this.p13 * this.f14;
  }
  get p19() {
    // =P14
    return this.p14;
  }

  get q6() {
    // =$N$69*F6
    return this.n69 * this.f6;
  }
  get q7() {
    // =Q6*F7
    return this.q6 * this.f7;
  }
  get q8() {
    // =Q7*F8
    return this.q7 * this.f8;
  }
  get q13() {
    // =Q8*F13
    return this.q8 * this.f13;
  }
  get q14() {
    // =Q13*F14
    return this.q13 * this.f14;
  }
  get q19() {
    // =Q14
    return this.q14;
  }

  // outputSavingPotential
  get c22() {
    // =IF(F19=0,0,_xlfn.CONCAT((TEXT(P79,"$###,###,###"))," to ",(TEXT(Q79, "$###,###,###"))))
    if (this.f19 === 0) {
      return 0;
    } else if (this.p79 === this.q79) {
      return `Up to $${this.p79.toLocaleString()}`;
    } else if (this.p79 === 0) {
      return `Up to $${this.q79.toLocaleString()}`;
    } else {
      return `$${this.p79.toLocaleString()} to $${this.q79.toLocaleString()}`;
    }
  }
  // outputEffortReduction
  get c23() {
    // =IF(F19=0,0,IF(O82=550,"Greater Than "&O82,_xlfn.CONCAT((TEXT(O83,"###,###,###"))," to ",(TEXT(P83,"###,###,###")))))
    if (this.f19 === 0) {
      return 0;
    } else if (this.o82 === 550) {
      return `Greater than ${this.o82.toLocaleString()} business days`;
    } else {
      return `${this.o83.toLocaleString()} to ${this.p83.toLocaleString()} business days`;
    }
  }
  // outputReturnOnInvestment
  get c26() {
    // =IF(P78<H19,0,IF(F19=0,0,((P78-H19)/H19)))
    if (this.p78 < this.h19 || this.f19 === 0) {
      return 0;
    }
    return `${(this.p78 - this.h19) / this.h19}%`;
  }
}

export default SpreadsheetFormulas;

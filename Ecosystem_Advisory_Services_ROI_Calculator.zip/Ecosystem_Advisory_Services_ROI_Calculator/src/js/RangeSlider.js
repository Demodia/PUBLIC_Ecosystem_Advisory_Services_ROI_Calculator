import { makeAutoObservable, reaction } from 'mobx';

class RangeSlider {
  constructor(inputElement, manager) {
    this.inputElement = inputElement;
    this.manager = manager;
    this.state = null;
    this.rangeFormats = {};
    this.setup();
    makeAutoObservable(this);

    reaction(
      () => this.state?.state[this.inputElement.id]?.raw,
      rawValue => {
        if (rawValue !== undefined) {
          this.updateRangeInputElementValue();
        }
      }
    );
  }

  setState(state) {
    this.state = state;
  }

  setup() {
    this.inputElement.value = 0;
    const datalist = this.createDatalist();
    this.inputElement.setAttribute('list', datalist.id);
    this.inputElement.parentNode.appendChild(datalist);
    const tooltip = this.createTooltip();
    this.inputElement.parentNode.appendChild(tooltip);
    this.rangeFormats[this.inputElement.id] = this.parseRangeInputElementFormat();
  }

  createDatalist() {
    const datalist = document.createElement('datalist');
    datalist.id = `${this.inputElement.id}-markers`;

    let dataRange = this.inputElement.dataset.range;
    dataRange = dataRange.replace(/min/g, this.inputElement.min).replace(/max/g, this.inputElement.max);

    const rangeValues = JSON.parse(dataRange);

    rangeValues.forEach(rangeValue => {
      const option = document.createElement('option');
      option.value = rangeValue.limit;
      datalist.appendChild(option);
    });

    return datalist;
  }

  createTooltip() {
    const tooltip = document.createElement('output');
    tooltip.className = 'rangeOutput';
    return tooltip;
  }

  parseRangeInputElementFormat() {
    try {
      let min = this.inputElement.min;
      let max = this.inputElement.max;
      let dataRange = this.inputElement.dataset.range;

      dataRange = dataRange.replace(/min/g, min).replace(/max/g, max);

      let ranges = JSON.parse(dataRange);
      return ranges.map(format => {
        const { limit, label, weight } = format;
        return { limit: Number(limit), label, weight: String(weight) };
      });
    } catch (error) {
      console.error('Error parsing data-range attribute:', error);
    }
  }

  formatRangeInputElementValue(value) {
    try {
      const ranges = this.rangeFormats[this.inputElement.id];

      let label = '';
      let weight = '';
      for (let i = 0; i < ranges.length; i++) {
        if (value <= ranges[i].limit) {
          label = ranges[i].label;
          weight = ranges[i].weight;
          break;
        }
      }

      return { label, weight };
    } catch (error) {
      console.error('Error parsing data-range attribute:', error);
    }
  }

  calculateRangeInputPercentage(value, min, max) {
    return ((value - min) / (max - min)) * 100;
  }

  updateRangeInputElementValue() {
    const { value, min, max } = this.inputElement;
    const percentage = this.calculateRangeInputPercentage(value, min, max);
    this.inputElement.style.setProperty('--value', `${percentage}%`);
    this.inputElement.classList.add('has-value');
    const tooltip = this.inputElement.parentNode.lastElementChild;
    tooltip.textContent = Number(this.state.state[this.inputElement.id]?.raw).toLocaleString();
  }
}

export default RangeSlider;

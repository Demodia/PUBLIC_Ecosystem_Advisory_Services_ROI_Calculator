import { makeAutoObservable, reaction } from 'mobx';

class RangeSlider {
  constructor(inputElement, manager) {
    this.inputElement = inputElement;
    this.manager = manager;
    this.state = null;
    this.rangeFormats = {};
    this.setup();
    makeAutoObservable(this);
    this.outputElement = this.findOutputElement();
    this.bindEvents();

    reaction(
      () => this.state?.state[this.inputElement.id]?.raw,
      rawValue => {
        if (rawValue !== undefined) {
          this.updateRangeInputElementValue();
        }
      }
    );
  }

  configureNumberInput() {
    if (this.outputElement) {
      this.outputElement.min = this.inputElement.min;
      this.outputElement.max = this.inputElement.max;
      this.outputElement.step = this.inputElement.step;
    }
  }  

  findOutputElement() {
    const parentDiv = this.inputElement.closest('.row');
    return parentDiv ? parentDiv.querySelector('.range-value') : null;
  }  

  bindEvents() {
    this.inputElement.addEventListener('input', () => this.syncNumberInput());
    if (this.outputElement) {
      this.outputElement.addEventListener('input', () => this.syncRangeInput());
    }
  }

  syncRangeInput() {
    if (this.outputElement) {
      const { value } = this.outputElement;
      this.inputElement.value = Number(value);
      this.updateRangeInputElementValue();
  
      // Manually trigger the input event
      this.inputElement.dispatchEvent(new Event('input', { 'bubbles': true }));
    }
  }  
  
  syncNumberInput() {
    if (this.outputElement) {
      const { value } = this.inputElement;
      this.outputElement.value = Number(value);
      this.updateRangeInputElementValue();
    }
  }

  setState(state) {
    this.state = state;
  }

  setup() {
    this.inputElement.value = this.inputElement.min;
    const datalist = this.createDatalist();
    this.inputElement.setAttribute('list', datalist.id);
    this.inputElement.parentNode.appendChild(datalist);
    this.rangeFormats[this.inputElement.id] = this.parseRangeInputElementFormat();
  }

  createDatalist() {
    const datalist = document.createElement('datalist');
    datalist.id = `${this.inputElement.id}-markers`;

    let dataRange = this.inputElement.dataset.range;
    dataRange = dataRange.replace(/min/g, this.inputElement.min).replace(/max/g, this.inputElement.max);

    const rangeValues = JSON.parse(dataRange);

    rangeValues.forEach(rangeValue => {
      const option = document.createElement('option');
      option.value = rangeValue.limit;
      datalist.appendChild(option);
    });

    return datalist;
  }

  parseRangeInputElementFormat() {
    try {
      let min = this.inputElement.min;
      let max = this.inputElement.max;
      let dataRange = this.inputElement.dataset.range;

      dataRange = dataRange.replace(/min/g, min).replace(/max/g, max);

      let ranges = JSON.parse(dataRange);
      return ranges.map(format => {
        const { limit, label, weight } = format;
        return { limit: Number(limit), label, weight: String(weight) };
      });
    } catch (error) {
      console.error('Error parsing data-range attribute:', error);
    }
  }

  formatRangeInputElementValue(value) {
    try {
      const ranges = this.rangeFormats[this.inputElement.id];

      let label = '';
      let weight = '';
      for (let i = 0; i < ranges.length; i++) {
        if (value <= ranges[i].limit) {
          label = ranges[i].label;
          weight = ranges[i].weight;
          break;
        }
      }

      return { label, weight };
    } catch (error) {
      console.error('Error parsing data-range attribute:', error);
    }
  }

  calculateRangeInputPercentage(value, min, max) {
    return (((Number(value) - Number(min)) / (Number(max) - Number(min))) * 100);
  }

  updateRangeInputElementValue() {
    const value = Number(this.inputElement.value);
    const min = Number(this.inputElement.min);
    const max = Number(this.inputElement.max);
    const percentage = this.calculateRangeInputPercentage(value, min, max);
    this.inputElement.style.setProperty('--value', `${percentage}%`);
    this.inputElement.classList.add('has-value');
    if (this.outputElement) {
      this.outputElement.value = value;
    }
  }
}

export default RangeSlider;

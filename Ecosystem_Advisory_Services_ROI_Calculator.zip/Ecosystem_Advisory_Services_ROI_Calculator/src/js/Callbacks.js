/**
 * A class for managing callbacks.
 */
class Callbacks {
  /**
   * Creates a new instance of Callbacks.
   */
  constructor() {
    /**
     * A map of event names to callback functions.
     * @type {Map<string, Function>}
     */
    this.callbacks = new Map();
  }

  /**
   * Sets a callback function for the specified event.
   * @param {string} event - The name of the event.
   * @param {Function} callback - The callback function to set.
   * @throws {Error} Throws an error if the callback is not a function.
   */
  setCallback(event, callback) {
    if (typeof callback !== "function") {
      throw new Error(`Callback for event "${event}" must be a function, got ${typeof callback}`);
    }
    this.callbacks.set(event, callback);
  }

  /**
   * Removes the callback function for the specified event.
   * @param {string} event - The name of the event.
   */
  removeCallback(event) {
    this.callbacks.delete(event);
  }

  /**
   * Invokes the callback function for the specified event.
   * @param {string} event - The name of the event.
   */
  invokeCallback(event) {
    const callback = this.callbacks.get(event);
    callback && callback();
  }
}

export default Callbacks;

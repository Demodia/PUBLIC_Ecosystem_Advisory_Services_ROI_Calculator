import { makeObservable, action, computed, autorun } from "mobx";
import SpreadsheetFormulas from "./SpreadsheetFormulas.js";

const CALLBACKS = {
  USER_INTERACTED: "userInteracted",
  ALL_FIELDS_VALID: "allFieldsValid",
  RESULTS_CALCULATED: "resultsCalculated",
};

class EventHandlers {
  constructor(calculatorElement, buttonElements, inputElements, outputElements, resultElements, calculatorState, rangeSliders, callbacks, requiredFieldIDs) {
    this.calculatorElement = calculatorElement;
    this.buttonElements = buttonElements;
    this.inputElements = inputElements;
    this.outputElements = outputElements;
    this.resultElements = resultElements;
    this.calculatorState = calculatorState;
    this.rangeSliders = rangeSliders;
    this.callbacks = callbacks;
    this.requiredFieldIDs = requiredFieldIDs;

    makeObservable(this, {
      areAllFieldsValid: computed,
      handleInputEvent: action.bound,
      handleClickEvent: action.bound,
      handleCalculate: action.bound,
      handleReset: action.bound,
      handleStateUpdate: action.bound,
      handleEvent: action.bound,
    });

    autorun(() => this.handleCalculate());

    this.enableResetButton = this.enableResetButton.bind(this);
    this.enableCalculateButton = this.enableCalculateButton.bind(this);
    this.handleResultsCalculated = this.handleResultsCalculated.bind(this);
  }

  get areAllFieldsValid() {
    return this.requiredFieldIDs.every((field) => this.calculatorState.state[field]?.value !== undefined);
  }

  handleInputEvent(target) {
    if (target.matches("select.calc-field.form-control")) {
      this.handleSelectInput(target);
    } else if (target.matches(".calc-field.form-control-range")) {
      this.handleRangeInput(target);
    }

    if (target.matches("select.calc-field.form-control, .calc-field.form-control-range")) {
      this.handleUserInteraction(target);
    }
  }

  handleSelectInput(target) {
    const { options, value } = target;
    const weight = options[target.selectedIndex].dataset.value;
    this.handleStateUpdate(target.id, value, weight);
  }

  handleRangeInput(target) {
    const { id, value, min, max } = target;
    const slider = this.rangeSliders.get(id);
    const percentage = slider.calculateRangeInputPercentage(value, min, max);
    target.style.setProperty("--value", `${percentage}%`);
    target.classList.add("has-value");
    const formattedValue = slider.formatRangeInputElementValue(value);
    this.handleStateUpdate(id, value, formattedValue);
  }

  handleUserInteraction(target) {
    const { id, value } = target;
    this.callbacks.invokeCallback(CALLBACKS.USER_INTERACTED);
    this.callbacks.removeCallback(CALLBACKS.USER_INTERACTED);
  }

  handleClickEvent(target, calculatorElement) {
    if (target.matches("#resetProgressButton")) {
      this.handleResetClick();
    } else if (target.matches("#getResultsButton")) {
      this.handleCalculateClick();
    } else if (target.matches("#goToCalculatorButton")) {
      this.handleGoToCalculatorClick(calculatorElement);
    }
  }

  handleResetClick() {
    this.handleReset();
  }

  handleCalculateClick() {
    this.handleCalculate();
  }

  handleGoToCalculatorClick(calculatorElement) {
    calculatorElement.scrollIntoView({ behavior: "smooth" });
  }

  handleCalculate() {
    if (!this.areAllFieldsValid) return;

    const formulas = new SpreadsheetFormulas(this.calculatorState.state);

    formulas.logGetterValues();

    const savingPotential = formulas.c22;
    const effortReduction = formulas.c23;
    const returnOnInvestment = formulas.c26;

    // Update the state directly
    this.calculatorState.state.outputSavingPotential = savingPotential;
    this.calculatorState.state.outputEffortReduction = effortReduction;
    this.calculatorState.state.outputReturnOnInvestment = returnOnInvestment;

    this.callbacks.invokeCallback(CALLBACKS.RESULTS_CALCULATED);

    document.getElementById("resultsBlocks").scrollIntoView({ behavior: "smooth" });
  }

  resetButtonElements() {
    this.buttonElements.resetProgress.disabled = true;
    this.buttonElements.getResults.disabled = true;
    this.buttonElements.getResults.hidden = false;
    this.resultElements.preResults.hidden = false;
    this.resultElements.calculatorOutputs.hidden = true;
    this.resultElements.requestConsultation.hidden = true;
  }

  handleReset() {
    this.calculatorState.reset();
    this.resetButtonElements();
    this.calculatorElement.scrollIntoView({ behavior: "smooth" });

    // Hide the Speak to an expert block using jQuery because Bootstrap 4.6
    $("#speakToAnExpertBlock").collapse("hide");

    this.callbacks.setCallback(CALLBACKS.USER_INTERACTED, this.enableResetButton);
    this.callbacks.setCallback(CALLBACKS.ALL_FIELDS_VALID, this.enableCalculateButton);
    this.callbacks.setCallback(CALLBACKS.RESULTS_CALCULATED, this.handleResultsCalculated);
  }

  handleStateUpdate(id, value, weight) {
    const getUpdatedFieldValue = (rangeSliders, id, value, weight) => {
      if (id.startsWith("select")) return { value: value, data: weight };
      {
        const slider = rangeSliders.get(id);
        const { label: label, weight: weight } = slider.formatRangeInputElementValue(value);
        return { raw: Number(value), value: label, data: weight };
      }
    };
    const isFieldValueChanged = (oldValue, newValue) => JSON.stringify(oldValue) !== JSON.stringify(newValue);
    const newValue = getUpdatedFieldValue(this.rangeSliders, id, value, weight);

    if (isFieldValueChanged(this.calculatorState.state[id], newValue)) {
      this.calculatorState.set(id, newValue);

      this.areAllFieldsValid && this.callbacks.invokeCallback(CALLBACKS.ALL_FIELDS_VALID);

      this.calculatorState.state.outputSavingPotential !== null && this.handleCalculate();
    }
  }

  handleEvent(event) {
    const { target } = event;

    target.matches(".calc-field") && event.type === "input" && this.handleInputEvent(target);
    target.matches(".calc-button") && event.type === "click" && this.handleClickEvent(target, this.calculatorElement);
  }

  setupEventHandlers() {
    this.calculatorElement.addEventListener("input", this.handleEvent);
    this.calculatorElement.addEventListener("click", this.handleEvent);
  }

  setupEventActions() {
    this.callbacks.setCallback(CALLBACKS.USER_INTERACTED, this.enableResetButton);
    this.callbacks.setCallback(CALLBACKS.ALL_FIELDS_VALID, this.enableCalculateButton);
    this.callbacks.setCallback(CALLBACKS.RESULTS_CALCULATED, this.handleResultsCalculated);
  }

  enableResetButton() {
    this.buttonElements.resetProgress.disabled = false;
  }

  enableCalculateButton() {
    this.buttonElements.getResults.disabled = false;

    this.callbacks.removeCallback(CALLBACKS.ALL_FIELDS_VALID);
  }

  handleResultsCalculated() {
    this.buttonElements.getResults.hidden = true;
    this.resultElements.preResults.hidden = true;
    this.resultElements.calculatorOutputs.hidden = false;
    this.resultElements.requestConsultation.hidden = false;

    this.callbacks.removeCallback(CALLBACKS.RESULTS_CALCULATED);
  }
}

export default EventHandlers;
